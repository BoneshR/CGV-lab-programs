#include<stdlib.h>
#include<GL/glut.h>
GLfloat ver[][3] = { { -1,-1,-1 },{ 1,-1,-1 },{ 1,1,-1 },{ -1,1,-1 },{ -1,-1,1 },{ 1,-1,1 },{ 1,1,1 },{ -
1,1,1} };
GLfloat col[][3] = { { 0,0,0 },{ 1,0,0 },{ 1,1,0 },{ 0,1,0 },{ 0,0,1 },{ 1,0,1 },{ 1,1,1 },{ 0,1,1 } };
void polygon(int a, int b, int c, int d) {
	glBegin(GL_POLYGON);
	glColor3fv(col[a]);
	glVertex3fv(ver[a]);
	glColor3fv(col[b]);
	glVertex3fv(ver[b]);
	glColor3fv(col[c]);
	glVertex3fv(ver[c]);
	glColor3fv(col[d]);
	glVertex3fv(ver[d]);
	glEnd();
}
void colorCube(void) {
	polygon(0, 3, 2, 1);
	polygon(2, 3, 7, 6);
	polygon(0, 4, 7, 3);
	polygon(1, 2, 6, 5);
	polygon(4, 5, 6, 7);
	polygon(0, 1, 5, 4);
}
static GLfloat th[] = { 0,0,0 };
static GLint axis = 0;
void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	glRotatef(th[0], 1, 0, 0);
	glRotatef(th[1], 0, 1, 0);
	glRotatef(th[2], 0, 0, 1);
	colorCube();
	glFlush();
	glutSwapBuffers();
}
void spinCube()
{
	th[axis] = th[axis] + 10;
	if (th[axis] > 360)
		th[axis] = th[axis] - 360;
	glutPostRedisplay();
}
void mouse(int btn, int state, int x, int y) {
	if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
		axis = 0;
	if (btn == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN)
		axis = 1;
	if (btn == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
		axis = 2;
}
void myReshape(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-2, 2, -2, 2, -10, 10);
	glMatrixMode(GL_MODELVIEW);
}
void main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutCreateWindow("colorCube");
	glutInitWindowSize(700, 700);
	glutReshapeFunc(myReshape);
	glutDisplayFunc(display);
	glutIdleFunc(spinCube);
	glutMouseFunc(mouse);
	glEnable(GL_DEPTH_TEST);
	glutMainLoop();
}